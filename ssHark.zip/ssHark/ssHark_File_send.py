import subprocess
subprocess.run(r'python your/path/here', shell=True) # dont delete "python "