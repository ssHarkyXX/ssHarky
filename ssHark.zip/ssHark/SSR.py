import subprocess
subprocess.run('pip install paramiko', shell=True)
import paramiko

def send_file_ssh():
    hostname = input("Enter the hostname (e.g., example.com): ")
    username = input("Enter the username: ")
    password = input("Enter the password: ")
    local_file_path = input("Enter the path to the local file: ")
    remote_destination_path = input("Enter the path on the remote server to save the file: ")

    # Create an SSH client object
    client = paramiko.SSHClient()

    # Set the connection policy (for security purposes, it's better to use stricter policies)
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Connect to the remote host
        client.connect(hostname=hostname, username=username, password=password)

        # Create an SFTP object for file transfer
        sftp = client.open_sftp()

        # Send the local file to the remote server
        sftp.put(local_file_path, remote_destination_path)

        print(f"File '{local_file_path}' successfully sent to '{hostname}:{remote_destination_path}'")

    except paramiko.AuthenticationException as auth_exception:
        print(f"Authentication error: {auth_exception}")
    except paramiko.SSHException as ssh_exception:
        print(f"SSH error: {ssh_exception}")
    finally:
        # Close the connections and sftp connection
        sftp.close()
        client.close()

# Example usage of the function to send a file to a remote host with input data
send_file_ssh()
