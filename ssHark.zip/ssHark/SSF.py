import subprocess
subprocess.run('pip install paramiko', shell=True)
import paramiko

def send_ssh_request():
    hostname = input("Enter the hostname (e.g., example.com): ")
    username = input("Enter the username: ")
    password = input("Enter the password: ")
    command = input("Enter the command to execute: ")

    # Create an SSH client object
    client = paramiko.SSHClient()

    # Set the connection policy (for security purposes, it's better to use stricter policies)
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())

    try:
        # Connect to the remote host
        client.connect(hostname=hostname, username=username, password=password)

        # Send the command via SSH
        stdin, stdout, stderr = client.exec_command(command)

        # Get the command execution result
        output = stdout.read().decode('utf-8')
        error = stderr.read().decode('utf-8')

        if output:
            print(f"Command execution result:\n{output}")
        if error:
            print(f"Command execution error:\n{error}")

    except paramiko.AuthenticationException as auth_exception:
        print(f"Authentication error: {auth_exception}")
    except paramiko.SSHException as ssh_exception:
        print(f"SSH error: {ssh_exception}")
    finally:
        # Close the connection
        client.close()

# Example usage of the function to send an SSH request with input data
send_ssh_request()
